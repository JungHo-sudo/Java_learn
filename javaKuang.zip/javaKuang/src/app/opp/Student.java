package app.opp;

public class Student extends Person {

        @Override
        public void action(){
            System.out.println("im a student");

        }


}
