package app.opp;

public class Person {

    public void action(){
        System.out.println("im beating as a person!");
    }

}
