package app.InnerClass;

public class Outer {

        public void method(){
            class Inner{
                public void in(){

                }
            }
        }
}



