package app.Service;

// interface定义的关键字,接口都需要有实现类

public interface UserService {
    // 接口中所有定义都是抽象 public abstract

    //常量
    // public static final int AGE = 99;
    // 一般不在接口中定义常量；

    int AGE = 99;

    void add(String name);
    void delete(String name);
    void update(String name);
    void query(String name);


}
