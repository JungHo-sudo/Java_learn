package app.Service;

public interface TImeService {
    void timer();
}
