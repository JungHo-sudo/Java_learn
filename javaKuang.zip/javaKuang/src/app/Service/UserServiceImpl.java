package app.Service;
/*
 实现类
 抽象类：extends
 类 可以实现接口 implements 接口（伪多继承）

 多继承 利用接口实现多继承
*/


public class UserServiceImpl implements UserService,TImeService{

    // command + N 快速实现方法

    @Override
    public void add(String name) {

    }

    @Override
    public void delete(String name) {

    }

    @Override
    public void update(String name) {

    }

    @Override
    public void query(String name) {

    }

    @Override
    public void timer() {

    }
}
