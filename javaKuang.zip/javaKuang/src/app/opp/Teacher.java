package app.opp;

public class Teacher extends Person{



}
