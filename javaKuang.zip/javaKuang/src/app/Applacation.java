package app;

import app.InnerClass.Outer;

public class Applacation {
    public static void main(String[] args) {
        Outer outer = new Outer();

        //通过外部类来实例化内部类；

    }
}
